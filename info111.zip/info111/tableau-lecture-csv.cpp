#include <stdexcept>
/** @file **/
#include <iostream>
#include <fstream>
#include <sstream>
#include "tableau-lecture-csv.hpp"


vector<vector<string>> litTableauCSV(string nom_fichier, int nb_colonnes) {
    // Remplacez cette ligne et la suivante par le code adéquat
    throw runtime_error("Fonction litTableauCSV non implantée ligne 11");
}

vector<vector<string>> litTableauCSV(string nom_fichier) {
    // Remplacez cette ligne et la suivante par le code adéquat
    throw runtime_error("Fonction litTableauCSV non implantée ligne 16");
}




