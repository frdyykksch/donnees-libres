#include <stdexcept>
/** @file **/
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

/** Calcule et affiche le prénom le plus utilisé une année donnée
 * ainsi que le nombre de naissances cette année là **/
int main() {
    // Remplacez cette ligne et la suivante par le code adéquat
    throw runtime_error("Fonction main non implantée ligne 12");
}

